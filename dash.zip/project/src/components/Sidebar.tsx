import React from 'react';
import { 
  Calendar, Users, Stethoscope, Image, Users2, 
  Wallet, BarChart3, CreditCard, Package, Monitor,
  FileText, HeadphonesIcon, ChevronDown, Building2
} from 'lucide-react';

const Sidebar = () => {
  return (
    <div className="w-64 h-screen bg-white border-r border-gray-100 flex flex-col">
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-blue-500 rounded-lg"></div>
          <span className="text-xl font-semibold text-gray-900">niah</span>
        </div>
      </div>
      
      <div className="px-3 py-2">
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div>
            <p className="text-sm font-medium text-gray-900">Artesia Clinic</p>
            <p className="text-xs text-gray-500">San Francisco, CA</p>
          </div>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </div>
      </div>

      <nav className="flex-1 px-3 py-4">
        <div className="space-y-6">
          <div>
            <p className="px-3 text-xs font-semibold text-gray-400 uppercase">CLINIC</p>
            <div className="mt-3 space-y-1">
              {[
                { icon: Calendar, label: 'Reservations' },
                { icon: Users, label: 'Patients' },
                { icon: Stethoscope, label: 'Treatments' },
                { icon: Image, label: 'Imaging' },
                { icon: Users2, label: 'Staff List' },
              ].map((item) => (
                <button
                  key={item.label}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-600 rounded-lg hover:bg-gray-50 hover:text-gray-900"
                >
                  <item.icon className="w-4 h-4 mr-3" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="px-3 text-xs font-semibold text-gray-400 uppercase">FINANCE</p>
            <div className="mt-3 space-y-1">
              {[
                { icon: Wallet, label: 'Accounts' },
                { icon: BarChart3, label: 'Sales' },
                { icon: Building2, label: 'Purchases' },
                { icon: CreditCard, label: 'Payment Method' },
              ].map((item) => (
                <button
                  key={item.label}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-600 rounded-lg hover:bg-gray-50 hover:text-gray-900"
                >
                  <item.icon className="w-4 h-4 mr-3" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="px-3 text-xs font-semibold text-gray-400 uppercase">PHYSICAL ASSET</p>
            <div className="mt-3 space-y-1">
              {[
                { icon: Package, label: 'Stocks' },
                { icon: Monitor, label: 'Peripherals' },
              ].map((item) => (
                <button
                  key={item.label}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-600 rounded-lg hover:bg-gray-50 hover:text-gray-900"
                >
                  <item.icon className="w-4 h-4 mr-3" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      <div className="p-3 mt-auto">
        <div className="space-y-1">
          {[
            { icon: FileText, label: 'Report' },
            { icon: HeadphonesIcon, label: 'Customer Support' },
          ].map((item) => (
            <button
              key={item.label}
              className="flex items-center w-full px-3 py-2 text-sm text-gray-600 rounded-lg hover:bg-gray-50 hover:text-gray-900"
            >
              <item.icon className="w-4 h-4 mr-3" />
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;