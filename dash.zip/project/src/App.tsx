import React from 'react';
import Sidebar from './components/Sidebar';
import OrganicSphere from './components/OrganicSphere';

function App() {
  return (
    <div className="flex min-h-screen bg-gray-50 font-[-apple-system,BlinkMacSystemFont,'SF Pro Display','SF Pro Text',system-ui]">
      <Sidebar />
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 relative">
                <OrganicSphere />
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-gray-900">Welcome back, Dr. Smith</h1>
                <p className="text-sm text-gray-500">Here's what's happening at your clinic today</p>
              </div>
            </div>
          </div>

          {/* Placeholder for dashboard content */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Add your dashboard widgets here */}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;